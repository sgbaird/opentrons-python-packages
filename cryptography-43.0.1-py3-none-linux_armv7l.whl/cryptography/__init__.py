"""
Comprehensive cryptography fallback for ARM environments.
Provides essential cryptography interfaces using standard library.
"""
import warnings

warnings.warn("Using cryptography fallback implementation. "
              "Some advanced features may be limited but core functionality is available.", 
              RuntimeWarning, stacklevel=2)

__version__ = "43.0.1"

# Export key components
from .fernet import Fernet
from .hazmat import hazmat

__all__ = ['Fernet', 'hazmat', '__version__']
