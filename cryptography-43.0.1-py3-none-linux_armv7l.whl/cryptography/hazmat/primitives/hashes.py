"""
Hash algorithms fallback using hashlib.
"""
import hashlib

class Hash:
    """Generic hash interface"""
    def __init__(self, algorithm):
        self.algorithm = algorithm
        self._ctx = algorithm()
    
    def update(self, data):
        self._ctx.update(data)
    
    def finalize(self):
        return self._ctx.digest()

class SHA256:
    """SHA256 hash algorithm"""
    def __call__(self):
        return hashlib.sha256()
    
    @property 
    def digest_size(self):
        return 32

class SHA1:
    """SHA1 hash algorithm"""
    def __call__(self):
        return hashlib.sha1()
    
    @property
    def digest_size(self):
        return 20

class MD5:
    """MD5 hash algorithm"""
    def __call__(self):
        return hashlib.md5()
    
    @property
    def digest_size(self):
        return 16

# Instances
SHA256 = SHA256()
SHA1 = SHA1()
MD5 = MD5()
