"""
Serialization fallback implementations.
"""
import base64
import json

class Encoding:
    """Encoding options"""
    PEM = "PEM"
    DER = "DER"
    Raw = "Raw"

class PrivateFormat:
    """Private key format options"""
    PKCS8 = "PKCS8"
    TraditionalOpenSSL = "TraditionalOpenSSL"
    Raw = "Raw"

class PublicFormat:
    """Public key format options"""
    SubjectPublicKeyInfo = "SubjectPublicKeyInfo"
    PKCS1 = "PKCS1"
    Raw = "Raw"

class NoEncryption:
    """No encryption option"""
    pass

def load_pem_private_key(data, password=None):
    """Fallback PEM private key loader"""
    return {"type": "private_key", "data": data, "password": password}

def load_pem_public_key(data):
    """Fallback PEM public key loader"""
    return {"type": "public_key", "data": data}
