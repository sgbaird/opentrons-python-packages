"""
Cryptographic primitives fallback.
"""
from . import hashes, serialization

__all__ = ['hashes', 'serialization']
