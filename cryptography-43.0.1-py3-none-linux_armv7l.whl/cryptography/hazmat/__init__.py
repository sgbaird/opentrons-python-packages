"""
Hazmat (Hazardous Materials) fallback implementation.
"""
from . import primitives, backends

__all__ = ['primitives', 'backends']
