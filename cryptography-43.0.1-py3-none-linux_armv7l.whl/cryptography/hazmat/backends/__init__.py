"""
Cryptographic backends fallback.
"""
class Backend:
    """Fallback backend"""
    pass

def default_backend():
    """Return default backend"""
    return Backend()
