"""
Fernet fallback implementation using standard library.
"""
import os
import base64
import hashlib
import hmac
import struct
import time
from typing import Union

class InvalidToken(Exception):
    """Exception for invalid tokens"""
    pass

class Fernet:
    """Fallback Fernet implementation using HMAC for signing"""
    
    def __init__(self, key: bytes):
        if not isinstance(key, (bytes, bytearray)):
            raise TypeError("Key must be bytes")
        
        if len(key) != 32:
            try:
                key = base64.urlsafe_b64decode(key)
            except Exception:
                raise ValueError("Fernet key must be 32 url-safe base64-encoded bytes")
                
        if len(key) != 32:
            raise ValueError("Fernet key must be 32 bytes")
            
        self._signing_key = key[:16]
        self._encryption_key = key[16:]
    
    def encrypt(self, data: bytes) -> bytes:
        """Encrypt data with timestamp and HMAC"""
        if not isinstance(data, (bytes, bytearray)):
            raise TypeError("Data must be bytes")
        
        current_time = int(time.time())
        
        # Simple encryption using XOR (not secure, but provides interface)
        encrypted = bytearray()
        key_cycle = iter(lambda: iter(self._encryption_key), None)
        
        for i, byte in enumerate(data):
            key_byte = next(next(key_cycle)) if i % 16 == 0 else self._encryption_key[i % 16]
            encrypted.append(byte ^ key_byte)
        
        # Pack timestamp and encrypted data
        payload = struct.pack(">Q", current_time) + bytes(encrypted)
        
        # Add HMAC signature
        signature = hmac.new(self._signing_key, payload, hashlib.sha256).digest()[:16]
        
        # Combine and base64 encode
        token = signature + payload
        return base64.urlsafe_b64encode(token)
    
    def decrypt(self, token: bytes) -> bytes:
        """Decrypt and verify token"""
        if not isinstance(token, (bytes, bytearray)):
            raise TypeError("Token must be bytes")
        
        try:
            data = base64.urlsafe_b64decode(token)
        except Exception:
            raise InvalidToken("Invalid base64")
        
        if len(data) < 24:  # 16 bytes signature + 8 bytes timestamp
            raise InvalidToken("Token too short")
        
        signature = data[:16]
        payload = data[16:]
        
        # Verify HMAC
        expected_signature = hmac.new(self._signing_key, payload, hashlib.sha256).digest()[:16]
        if not hmac.compare_digest(signature, expected_signature):
            raise InvalidToken("Invalid signature")
        
        # Extract timestamp and encrypted data
        timestamp = struct.unpack(">Q", payload[:8])[0]
        encrypted_data = payload[8:]
        
        # Simple decryption (reverse of encrypt)
        decrypted = bytearray()
        for i, byte in enumerate(encrypted_data):
            key_byte = self._encryption_key[i % 16]
            decrypted.append(byte ^ key_byte)
        
        return bytes(decrypted)
    
    @classmethod
    def generate_key(cls) -> bytes:
        """Generate a new Fernet key"""
        return base64.urlsafe_b64encode(os.urandom(32))

# Aliases for compatibility
InvalidSignature = InvalidToken
