"""
ujson fallback implementation for ARMv7l compatibility.
Provides ujson-compatible interface using standard json module.
"""

import json as _json
import sys

__version__ = "5.10.0"

# Core ujson functions using standard json as backend
def loads(s, *args, **kwargs):
    """Load JSON from string - compatible with ujson.loads"""
    return _json.loads(s)

def dumps(obj, *args, **kwargs):
    """Dump object to JSON string - compatible with ujson.dumps"""
    # Handle common ujson kwargs
    ensure_ascii = kwargs.get('ensure_ascii', True)
    return _json.dumps(obj, ensure_ascii=ensure_ascii, separators=(',', ':'))

def load(fp, *args, **kwargs):
    """Load JSON from file - compatible with ujson.load"""
    return _json.load(fp)

def dump(obj, fp, *args, **kwargs):
    """Dump object to JSON file - compatible with ujson.dump"""
    ensure_ascii = kwargs.get('ensure_ascii', True)
    return _json.dump(obj, fp, ensure_ascii=ensure_ascii, separators=(',', ':'))

# Aliases for compatibility
decode = loads
encode = dumps