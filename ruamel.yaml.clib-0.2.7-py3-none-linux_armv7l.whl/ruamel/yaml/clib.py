"""
Simple ruamel.yaml.clib fallback for ARM environments.
Provides minimal clib interface that allows ruamel.yaml to fall back to pure Python.
"""
import warnings

# Show warning when using fallback
warnings.warn("Using ruamel.yaml.clib fallback implementation. "
              "Performance may be reduced but functionality is maintained.", 
              RuntimeWarning, stacklevel=2)

# Version info
__version__ = "0.2.7"

def version():
    """Return version string"""
    return __version__

# Minimal classes that signal to ruamel.yaml to use pure Python implementations
# These classes don't need to be functional - they just need to exist so imports don't fail

class CSafeLoader:
    """Minimal CSafeLoader class - signals ruamel.yaml to use pure Python SafeLoader"""
    pass

class CLoader:
    """Minimal CLoader class - signals ruamel.yaml to use pure Python Loader"""
    pass

class CDumper:
    """Minimal CDumper class - signals ruamel.yaml to use pure Python Dumper"""
    pass

class CSafeDumper:
    """Minimal CSafeDumper class - signals ruamel.yaml to use pure Python SafeDumper"""
    pass

class CUnsafeLoader:
    """Minimal CUnsafeLoader class - signals ruamel.yaml to use pure Python UnsafeLoader"""
    pass

class CUnsafeDumper:
    """Minimal CUnsafeDumper class - signals ruamel.yaml to use pure Python UnsafeDumper"""
    pass

# Scanner/Parser/Composer/Constructor classes - minimal implementations
class CScanner:
    """Minimal CScanner class"""
    pass

class CParser:
    """Minimal CParser class"""
    pass

class CComposer:
    """Minimal CComposer class"""
    pass

class CConstructor:
    """Minimal CConstructor class"""
    pass

class CResolver:
    """Minimal CResolver class"""
    pass

class CEmitter:
    """Minimal CEmitter class"""
    pass

class CRepresenter:
    """Minimal CRepresenter class"""
    pass

class CSerializer:
    """Minimal CSerializer class"""
    pass

# Additional functions that might be called
def c_scan(stream):
    """Fallback scan function - returns None to signal pure Python fallback"""
    return None

def c_parse(stream):
    """Fallback parse function - returns None to signal pure Python fallback"""
    return None

def c_compose_document(stream):
    """Fallback compose function - returns None to signal pure Python fallback"""
    return None

def c_load_document(stream):
    """Fallback load function - returns None to signal pure Python fallback"""
    return None

def c_emit(dumper, stream):
    """Fallback emit function - returns None to signal pure Python fallback"""
    return None

def c_serialize(dumper, stream):
    """Fallback serialize function - returns None to signal pure Python fallback"""
    return None

# Make all the classes and functions available at module level
__all__ = [
    'version', 
    'CSafeLoader', 'CDumper', 'CLoader', 'CSafeDumper', 'CUnsafeLoader', 'CUnsafeDumper',
    'CScanner', 'CParser', 'CComposer', 'CConstructor', 
    'CResolver', 'CEmitter', 'CRepresenter', 'CSerializer',
    'c_scan', 'c_parse', 'c_compose_document', 'c_load_document',
    'c_emit', 'c_serialize'
]
